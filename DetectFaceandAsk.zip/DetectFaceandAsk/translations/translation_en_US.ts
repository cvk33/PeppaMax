<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Actions (1)/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>obstacle</source>
            <comment>Text</comment>
            <translation type="unfinished">obstacle</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Actions (2)/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>obstacle</source>
            <comment>Text</comment>
            <translation type="unfinished">obstacle</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Actions/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>obstacle</source>
            <comment>Text</comment>
            <translation type="unfinished">obstacle</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Detect_and_Ask/Say</name>
        <message>
            <source>Dai jo bu ka?</source>
            <comment>Text</comment>
            <translation type="obsolete">Dai jo bu ka?</translation>
        </message>
        <message>
            <source>you okay?</source>
            <comment>Text</comment>
            <translation type="obsolete">you okay?</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>dai jou bu?</source>
            <comment>Text</comment>
            <translation type="unfinished">dai jou bu?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Detect_and_Ask/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Jun san O K</source>
            <comment>Text</comment>
            <translation type="obsolete">Jun san O K</translation>
        </message>
        <message>
            <source>Hai Jun</source>
            <comment>Text</comment>
            <translation type="obsolete">Hai Jun</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Jun san</source>
            <comment>Text</comment>
            <translation type="unfinished">Jun san</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Detect_and_Ask/Say (2)</name>
        <message>
            <source>Kao Mada desu</source>
            <comment>Text</comment>
            <translation type="obsolete">Kao Mada desu</translation>
        </message>
        <message>
            <source>Hai David</source>
            <comment>Text</comment>
            <translation type="obsolete">Hai David</translation>
        </message>
        <message>
            <source>he lo David san</source>
            <comment>Text</comment>
            <translation type="obsolete">he lo David san</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>David san</source>
            <comment>Text</comment>
            <translation type="unfinished">David san</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/EmotionDetect/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>fu zu</source>
            <comment>Text</comment>
            <translation type="obsolete">fu zu</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/EmotionDetect/Animated Say (1)</name>
        <message>
            <source>u re shi i</source>
            <comment>Text</comment>
            <translation type="obsolete">u re shi i</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/EmotionDetect/Animated Say (2)</name>
        <message>
            <source>bikkuri</source>
            <comment>Text</comment>
            <translation type="obsolete">bikkuri</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/EmotionDetect/Animated Say (3)</name>
        <message>
            <source>oooi</source>
            <comment>Text</comment>
            <translation type="obsolete">oooi</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/EmotionDetect/Animated Say (4)</name>
        <message>
            <source>kanashii</source>
            <comment>Text</comment>
            <translation type="obsolete">kanashii</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/EmotionDetect/Animated Say (5)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Nan De syou</source>
            <comment>Text</comment>
            <translation type="obsolete">Nan De syou</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/ExecuteNo/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Sim Pai nai de ku da sai</source>
            <comment>Text</comment>
            <translation type="obsolete">Sim Pai nai de ku da sai</translation>
        </message>
        <message>
            <source>No worries</source>
            <comment>Text</comment>
            <translation type="obsolete">No worries</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>sim pai shi nai de ku da sai</source>
            <comment>Text</comment>
            <translation type="unfinished">sim pai shi nai de ku da sai</translation>
        </message>
        <message>
            <source>i will call your friend for help</source>
            <comment>Text</comment>
            <translation type="obsolete">i will call your friend for help</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/ExecuteNo/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>e me ru sen to</source>
            <comment>Text</comment>
            <translation type="unfinished">e me ru sen to</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/ExecuteNo/Say (2)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>sen to fe ru</source>
            <comment>Text</comment>
            <translation type="unfinished">sen to fe ru</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/ExecuteOK/Animated Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Hei ki, hei ki</source>
            <comment>Text</comment>
            <translation type="obsolete">Hei ki, hei ki</translation>
        </message>
        <message>
            <source>All is well</source>
            <comment>Text</comment>
            <translation type="obsolete">All is well</translation>
        </message>
        <message>
            <source>Hei ki hei ki</source>
            <comment>Text</comment>
            <translation type="obsolete">Hei ki hei ki</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Hei ki ne</source>
            <comment>Text</comment>
            <translation type="unfinished">Hei ki ne</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Listening Order/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>yokatta</source>
            <comment>Text</comment>
            <translation type="unfinished">yokatta</translation>
        </message>
        <message>
            <source>very well then</source>
            <comment>Text</comment>
            <translation type="obsolete">very well then</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Listening Order/Say (1)</name>
        <message>
            <source>ikimasu</source>
            <comment>Text</comment>
            <translation type="obsolete">ikimasu</translation>
        </message>
        <message>
            <source>i will help you</source>
            <comment>Text</comment>
            <translation type="obsolete">i will help you</translation>
        </message>
        <message>
            <source>ikimas</source>
            <comment>Text</comment>
            <translation type="obsolete">ikimas</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>to mo dachi to yon de imasu</source>
            <comment>Text</comment>
            <translation type="unfinished">to mo dachi to yon de imasu</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Good then</source>
            <comment>Text</comment>
            <translation type="obsolete">Good then</translation>
        </message>
        <message>
            <source>konichiwa</source>
            <comment>Text</comment>
            <translation type="obsolete">konichiwa</translation>
        </message>
        <message>
            <source>good then</source>
            <comment>Text</comment>
            <translation type="obsolete">good then</translation>
        </message>
        <message>
            <source>yokatta</source>
            <comment>Text</comment>
            <translation type="obsolete">yokatta</translation>
        </message>
        <message>
            <source>u re shi</source>
            <comment>Text</comment>
            <translation type="obsolete">u re shi</translation>
        </message>
        <message>
            <source>Arigatou</source>
            <comment>Text</comment>
            <translation type="obsolete">Arigatou</translation>
        </message>
        <message>
            <source>hi hi !</source>
            <comment>Text</comment>
            <translation type="obsolete">hi hi !</translation>
        </message>
        <message>
            <source>nan de syou</source>
            <comment>Text</comment>
            <translation type="obsolete">nan de syou</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Help Help</source>
            <comment>Text</comment>
            <translation type="obsolete">Help Help</translation>
        </message>
        <message>
            <source>i will help you</source>
            <comment>Text</comment>
            <translation type="obsolete">i will help you</translation>
        </message>
        <message>
            <source>ikimasu</source>
            <comment>Text</comment>
            <translation type="obsolete">ikimasu</translation>
        </message>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Mawarimas</source>
            <comment>Text</comment>
            <translation type="obsolete">Mawarimas</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>hidari Mawarimas</source>
            <comment>Text</comment>
            <translation type="unfinished">hidari Mawarimas</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Dai jo bu ka?</source>
            <comment>Text</comment>
            <translation type="obsolete">Dai jo bu ka?</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Migi Mawarimas</source>
            <comment>Text</comment>
            <translation type="unfinished">Migi Mawarimas</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Sen Ta</source>
            <comment>Text</comment>
            <translation type="unfinished">Sen Ta</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/SoundSearch (1)/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Ha Lo david</source>
            <comment>Text</comment>
            <translation type="unfinished">Ha Lo david</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/SoundSearch (1)/Say (1)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Ha lo Jun</source>
            <comment>Text</comment>
            <translation type="unfinished">Ha lo Jun</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/SoundSearch/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Ha Lo david</source>
            <comment>Text</comment>
            <translation type="unfinished">Ha Lo david</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/SoundSearch/Say (1)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Ha lo Jun</source>
            <comment>Text</comment>
            <translation type="unfinished">Ha lo Jun</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/SoundSearch/Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>e</source>
            <comment>Text</comment>
            <translation type="obsolete">e</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>na ni</source>
            <comment>Text</comment>
            <translation type="unfinished">na ni</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/SoundSearch/Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>a i</source>
            <comment>Text</comment>
            <translation type="obsolete">a i</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>i</source>
            <comment>Text</comment>
            <translation type="unfinished">i</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/VoiceCMD_n_Scan/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Nani?</source>
            <comment>Text</comment>
            <translation type="obsolete">Nani?</translation>
        </message>
        <message>
            <source>Yes</source>
            <comment>Text</comment>
            <translation type="obsolete">Yes</translation>
        </message>
        <message>
            <source>Hai?</source>
            <comment>Text</comment>
            <translation type="obsolete">Hai?</translation>
        </message>
        <message>
            <source>Yes?</source>
            <comment>Text</comment>
            <translation type="obsolete">Yes?</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Na ni?</source>
            <comment>Text</comment>
            <translation type="unfinished">Na ni?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/VoiceCMD_n_Scan/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>jin rui o mita</source>
            <comment>Text</comment>
            <translation type="obsolete">jin rui o mita</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/VoiceCMD_n_Scan/Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>nai</source>
            <comment>Text</comment>
            <translation type="obsolete">nai</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/VoiceCMD_n_Scan/Say (3)</name>
        <message>
            <source>hai</source>
            <comment>Text</comment>
            <translation type="obsolete">hai</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/VoiceCMD_n_Scan/Say (4)</name>
        <message>
            <source>ie</source>
            <comment>Text</comment>
            <translation type="obsolete">ie</translation>
        </message>
    </context>
</TS>
